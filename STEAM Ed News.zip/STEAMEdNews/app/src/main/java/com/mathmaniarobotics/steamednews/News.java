package com.mathmaniarobotics.steamednews;
//This is the object and what we want to pass into the object

public class News {
    private String articleTitle, articleAuthor, articleSection, articleDate, articleUrl;

    public News (String articleTitle, String articleAuthor, String articleSection, String articleDate, String articleUrl) {
        this.articleTitle = articleTitle;
        this.articleAuthor = articleAuthor;
        this.articleSection = articleSection;
        this.articleDate = articleDate;
        this.articleUrl = articleUrl;
    }

    public String getArticleTitle() {return articleTitle;}
    public String getArticleAuthor() {return articleAuthor;}
    public String getArticleSection() {return articleSection;}
    public String getArticleDate() {return articleDate;}
    public String getArticleUrl() {return articleUrl;}

}
