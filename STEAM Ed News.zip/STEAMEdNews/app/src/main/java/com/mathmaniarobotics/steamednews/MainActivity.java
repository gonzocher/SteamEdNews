package com.mathmaniarobotics.steamednews;
//Follow udacity video at https://www.youtube.com/watch?v=Ai4JhyyFxcQ

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    public String requestURL = "https://content.guardianapis.com/search?api-key=96dd1917-a8fb-4aba-84b9-326bb8b03092";

    ListView newsListView;
    RelativeLayout emptyLayout;
    RelativeLayout noNewsLayout;
    RelativeLayout noNetworkLayout;
    RelativeLayout spinningLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {
        newsListView = findViewById(R.id.news_list);
        emptyLayout = findViewById(R.id.empty_layout);
        noNewsLayout = findViewById(R.id.news_no_news_layout);
        noNetworkLayout = findViewById(R.id.news_no_network_layout);
        spinningLayout = findViewById(R.id.spinning_layout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    /**
     * @param item The menu item that was selected.
     * @return boolean Return true to allow
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //if (id == R.id.refresh)   BUT that didn't work.  This whole section is different with SWITCH
        if (id == R.id.menu_settings) {
            Intent settingsIntent = new Intent(this, SettingsActivity.class);
            startActivity(settingsIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}


